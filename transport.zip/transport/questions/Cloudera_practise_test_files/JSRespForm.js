function initCustomInputs() {
    $('body').addClass('custom-inputs');
    $('.label_check, .label_radio').click(function () {
        setupLabel();
    });
    setupLabel();

    $('.question:nth-child(even)').addClass("even");

    $('.score').click(function () {
        if (!$(this).hasClass("selected")) {
            var response = $(this).html();
            var responseField = $(this).parent().next('.response');
            $(this).siblings().removeClass("selected");
            $(this).addClass("selected");
            responseField.val(response).change();
        }
    });
};
function setupLabel() {
    if ($('.label_check input').length) {
        $('.label_check').each(function () {
            $(this).removeClass('c_on');
        });
        $('.label_check input:checked').each(function () {
            $(this).parent('label').addClass('c_on');
        });
    };
    if ($('.label_radio input').length) {
        $('.label_radio').each(function () {
            $(this).removeClass('r_on');
        });
        $('.label_radio input:checked').each(function () {
            $(this).parent('label').addClass('r_on');
        });
    };
};

$(document).ready(function() {
    $('.one-click').on('click', function() {
        var link = $(this);
        if (link.hasClass('disabled')) {
            return false;
        }
        else {
            link.addClass('disabled');
            return true;
        }
    });
});

function enableLink(linkId) {
    alert(linkId);
    var link = $('#' + linkId);
    if (link.hasClass('disabled')) {
        link.removeClass('disabled');
    }
}