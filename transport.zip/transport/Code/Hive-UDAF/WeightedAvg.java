package com.walmart.ckp.car.udaf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.serde2.objectinspector.MapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StandardMapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;
import org.apache.hadoop.io.Text;

import com.walmart.ckp.car.utils.CalendarUtils;



/**
 * WeightedAvg - Generic UDAF.
 *
 */
@Description("_FUNC_(amount,year,month,tenure,referenceDate) - Returns the weighted average")
public class CopyOfWeightedAvg extends AbstractGenericUDAFResolver {
	
	//Double attribute,Integer tenure, Integer Year,Byte Month
	
	@Override
	public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters)
			throws SemanticException {
		if (parameters.length != 5) {
			
			throw new UDFArgumentTypeException(parameters.length - 1,
					"Exactly four arguments are expected.");
		}
		return new WeightedAvgDoubleEvaluator();
	}
	
	public static class WeightedAvgDoubleEvaluator extends GenericUDAFEvaluator {
		
		PrimitiveObjectInspector amountOI;
		PrimitiveObjectInspector yearOI;
		PrimitiveObjectInspector monthOI;
		PrimitiveObjectInspector tenureOI;
		PrimitiveObjectInspector refDateOI;
		
		Text result;
		Object partialResult[];
		
		StructObjectInspector soi;
		StructField avgMapField;
		StructField tenureField;
		
		MapObjectInspector avgMapFieldOI;
		StringObjectInspector tenureFieldOI;
		
		PrimitiveObjectInspector inputMapKeyOI;
		ObjectInspector inputMapValueOI;
		
		public static class WeightedAvgAggr implements AggregationBuffer {

				Map avgMap;
				Text tenure;
		};
		
		public ObjectInspector init(Mode mode, ObjectInspector[] parameters)
				throws HiveException {
			super.init(mode,parameters);
		
			if (mode == Mode.PARTIAL1 || mode == Mode.COMPLETE) {
			
				amountOI = (PrimitiveObjectInspector) parameters[0];
				yearOI = (PrimitiveObjectInspector) parameters[1];
				monthOI = (PrimitiveObjectInspector) parameters[2];
				tenureOI = (PrimitiveObjectInspector) parameters[3];
				refDateOI = (PrimitiveObjectInspector) parameters[4];
				
			} else {
				
				soi = (StructObjectInspector) parameters[0];
				avgMapField = soi.getStructFieldRef("avgMapField");
				tenureField = soi.getStructFieldRef("tenureField");
				
				tenureFieldOI = (StringObjectInspector) tenureField
						.getFieldObjectInspector();
				avgMapFieldOI = (StandardMapObjectInspector) avgMapField
						.getFieldObjectInspector();
				
				inputMapValueOI =  avgMapFieldOI
						.getMapValueObjectInspector();
				inputMapKeyOI = (PrimitiveObjectInspector) avgMapFieldOI
						.getMapKeyObjectInspector();
			}
			
			if (mode == Mode.PARTIAL1 || mode == Mode.PARTIAL2) {

				ArrayList<ObjectInspector> foi = new ArrayList<ObjectInspector>();
				StringObjectInspector genreKeyOI = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
				StringObjectInspector genreValueOI = PrimitiveObjectInspectorFactory.writableStringObjectInspector;
				
				foi.add(ObjectInspectorFactory
						.getStandardMapObjectInspector(genreKeyOI, genreValueOI));
				
				foi.add(PrimitiveObjectInspectorFactory.writableStringObjectInspector);

				ArrayList<String> fname = new ArrayList<String>();
				fname.add("avgMapField");
				fname.add("tenureField");
				
				partialResult = new Object[2];
				partialResult[0] = new Object();
				partialResult[1] = new Text();
				return ObjectInspectorFactory.getStandardStructObjectInspector(
						fname, foi);
			} else {
				result = new Text();
				return PrimitiveObjectInspectorFactory.writableStringObjectInspector;
			}
		}
		
		@Override
		public AggregationBuffer getNewAggregationBuffer() throws HiveException {
			
			WeightedAvgAggr newAggregationBuffer = new WeightedAvgAggr();
			reset(newAggregationBuffer);
			
			return newAggregationBuffer;	
		}

		@Override
		public void reset(AggregationBuffer agg) throws HiveException {

			WeightedAvgAggr ag = (WeightedAvgAggr) agg;

			ag.avgMap = new HashMap();
			ag.tenure = null;
		}

		@Override
		public void iterate(AggregationBuffer agg, Object[] parameters)
				throws HiveException {
			
			WeightedAvgAggr aggregation = (WeightedAvgAggr) agg;
			String tenure = PrimitiveObjectInspectorUtils.getString(parameters[3], tenureOI);
			 
			 if(null == aggregation.tenure) {
			 	 aggregation.tenure = new Text(tenure);
			 }

			 double amount = PrimitiveObjectInspectorUtils.getDouble(parameters[0], amountOI);
			 int year = PrimitiveObjectInspectorUtils.getInt(parameters[1], yearOI);
			 int month = PrimitiveObjectInspectorUtils.getInt(parameters[2], monthOI);
			 String refDate = PrimitiveObjectInspectorUtils.getString(parameters[4], refDateOI);
			 int key;
			 
			 key = CalendarUtils.dateDiffInMonths(year, month,refDate);
		    	  if (key <= 12 && key > 0) {
		    		  aggregation.avgMap.put(new Text(""+key), new Text(""+amount)) ;
		    	  }
		}

		@Override
		public Object terminatePartial(AggregationBuffer agg)
				throws HiveException {
			
			WeightedAvgAggr aggr = (WeightedAvgAggr) agg;
			
			partialResult[0] = aggr.avgMap;
			partialResult[1] = aggr.tenure;
			
			return partialResult;
		}

		@Override
		public void merge(AggregationBuffer agg, Object partial)
				throws HiveException {

			WeightedAvgAggr aggregation = (WeightedAvgAggr) agg;
			
			Object partialAvgMap = soi.getStructFieldData(partial,
					avgMapField);
			Object partialTenure = soi.getStructFieldData(partial,
					tenureField);
			
			Map avgMap = avgMapFieldOI.getMap(partialAvgMap);
			
			String tenureField = tenureFieldOI
					.getPrimitiveJavaObject(partialTenure);
			
			Iterator itrAvgMap = avgMap.keySet().iterator();
			Map avgOutMap = new HashMap();
			while (itrAvgMap.hasNext()) {
				Text key = (Text) itrAvgMap.next();
				putIntoMap(key, avgMap.get(key), avgOutMap);
			}
			aggregation.avgMap.putAll(avgOutMap);
			System.out.println(" agg.tenure " + aggregation.tenure);
			System.out.println(" tenure field " + tenureField);
			if (null == aggregation.tenure ) {
				System.out.println(" assigning tenure field");
				aggregation.tenure = new Text(tenureField);
			}
		}

		protected void putIntoMap(Object key, Object value, Map map) {
			
			Object pKeyCopy = ObjectInspectorUtils.copyToStandardObject(key,
					this.inputMapKeyOI);
			Object pValueCopy = ObjectInspectorUtils.copyToStandardObject(
					value, this.inputMapValueOI);
			map.put(pKeyCopy, pValueCopy);
		}

		
		@Override
		public Object terminate(AggregationBuffer agg) throws HiveException {
			
			WeightedAvgAggr aggregation = (WeightedAvgAggr) agg;
			
			int count = 0;
			int tenure = Integer.parseInt(aggregation.tenure.toString());
			Map avgMap = aggregation.avgMap;
			
			double finalSum=0.0;
			double wtdAvg = 0;
	    	if(tenure <= 365){
	    		count = (byte) Math.round(tenure/30);
	    	}else{
	    		count = 12;
	    	}

	    	double tempVal=0.0;
	    	for (int i=0;i<count;i++) {
	    		if (null != avgMap.get(new Text(""+(count - i)))) {
	    			tempVal = Double.parseDouble(avgMap.get(new Text(""+(count - i))).toString());
	    		}
	    		finalSum = finalSum + ((i+1) * tempVal);
	    		tempVal = 0.0;
	    	}

	    	if (count != 0) {
	    		wtdAvg = finalSum / (( count * (count+1) /2));
	    	}
	    	result.set(""+wtdAvg);
	    	return result;
		}
	}
}
