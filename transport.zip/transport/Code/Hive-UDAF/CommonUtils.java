/**
 * 
 */
package com.walmart.ckp.car.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

/**
 *
 *
 */
public class CommonUtils {
	
	/**Encodes map to string using java serialization
	 * @param map
	 * @return String
	 */
	public static String encodeMaptoString(Map map) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(baos);
			oos.writeObject(map);
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return new String(Base64.encodeBase64(baos.toByteArray()));
	}
	/**Creates map from serialized map string
	 * @param encodedString
	 * @return Map
	 */
	public static Map decodeStringtoMap(String encodedString) {
		Object object = null;
		try {
			byte[] data = Base64.decodeBase64(encodedString.getBytes());
			ObjectInputStream ois = new ObjectInputStream(
					new ByteArrayInputStream(data));
			object = ois.readObject();
			ois.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return (Map) object;

	}
}
