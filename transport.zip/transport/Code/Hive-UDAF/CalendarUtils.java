package com.walmart.ckp.car.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarUtils {
	
    static SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd");
    static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMM");
    private static final Calendar calendar = Calendar.getInstance();
    
	/*
	 * 	 Function to return the difference in months 
	 * 
	 * 	 ie refDate - yearmonth 
	 * 
	 *	 Ex: year = 2011,month = 02 (these values would be taken from the row which is being iterated) 
	 *   refDate = 2012-09-13 
	 *   will return 19
	 */
    
	public static int dateDiffInMonths(int year,int month,String refDate) {
		int difference=0;
		
		try {
		
			Date parsedDate = dateParser.parse(refDate);
			calendar.setTime(parsedDate);
			int refMonth = 1 + calendar.get(Calendar.MONTH);
			int refYear = calendar.get(Calendar.YEAR);
			difference = ((refYear - year) * 12 + (refMonth - month));
		} catch (Exception e) {
			return 0;
		}
		return difference;
	}
}
